# Covid-Analysis
Covid-19 Global data is taken from https://ourworldindata.org/covid-deaths
